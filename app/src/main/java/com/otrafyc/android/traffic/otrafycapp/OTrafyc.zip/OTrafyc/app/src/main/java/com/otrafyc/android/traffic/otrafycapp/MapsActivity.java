package com.otrafyc.android.traffic.otrafycapp;

import android.Manifest;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.location.Location;
import android.net.Uri;
import android.opengl.Visibility;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.SupportMenuInflater;
import androidx.appcompat.view.menu.ActionMenuItem;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;


import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.getbase.floatingactionbutton.FloatingActionButton;
import com.github.aakira.expandablelayout.ExpandableLinearLayout;
import com.github.aakira.expandablelayout.ExpandableRelativeLayout;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.service.Common;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.internal.IGoogleMapDelegate;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.SquareCap;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.otrafyc.android.traffic.otrafycapp.Helper.CustomInfoWindow;
import com.otrafyc.android.traffic.otrafycapp.Remote_Package.IGoogleAPI;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class MapsActivity extends AppCompatActivity implements RoutingListener, OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener, GoogleMap.OnMarkerClickListener, NavigationView.OnNavigationItemSelectedListener {


    private GoogleMap mMap;


    //rotating marker boolean
    // private boolean isMarkerRotating =false;

    // Play services
    private static final int MY_PERMISSION_REQUEST_CODE = 7000;
    private static final int PLAY_SERVICE_RES_REQUEST = 7001;

    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;

    private static int UPDATE_INTERVAL = 3000;
    private static int FASTEST_INTERVAL = 1000;
    private static int DISPLACEMENT = 2;

    private LatLng currentLocation;


    private Marker mUserMarker;
    private Marker destinationMarker;


    private Button findUserButton;
    Button trafficLegendButton;


    private SwitchMaterial locationSwitch;

    // Places fragment
    AutocompleteSupportFragment places;

    SupportMapFragment mapFragment;


    DrawerLayout drawer;
    NavigationView navigationView;
    private RelativeLayout wholeScreen;
    ;


    //    for navigation menu animation
    static final float END_SCALE = 0.7f;


    //car animation
    private List<LatLng> polyLineList;

    private float v;
    private double lat, lng;
    private Handler handler;
    private LatLng currentPosition, startPosition, endPosition, destinationLatLng;
    private int index, next;

    private String destination;
//    private PolylineOptions polylineOptions, blackPolylineOptions;
//    private Polyline blackPolyline, greyPolyline;
    private List<Polyline> polylines;
    private static final int[] COLORS = new int[]{R.color.colorPrimary,R.color.colorAccent,R.color.rippleEffectColor,R.color.colorPrimaryDark,R.color.primary_dark_material_light};


    private IGoogleAPI mService;

   /* private Runnable drawPathRunnable = new Runnable() {
        @Override
        public void run() {
            if (index < polyLineList.size() - 1) {
                index++;
                next = index + 1;
            }

            if (index < polyLineList.size() - 1) {
                startPosition = polyLineList.get(index);
                endPosition = polyLineList.get(next);

            }


        }
    };
*/

    // private MenuItem supportActionBar;

    //it was private float getBearing

   /* public float getBearing(LatLng startPosition, LatLng endPosition) {
        double lat = Math.abs(startPosition.latitude - endPosition.latitude);
        double lng = Math.abs(startPosition.longitude - endPosition.longitude);
        if (startPosition.latitude < endPosition.latitude && startPosition.longitude < endPosition.longitude)
            return (float) (Math.toDegrees(Math.atan(lat / lng)));
        else if (startPosition.latitude >= endPosition.latitude && startPosition.longitude < endPosition.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lat / lng))) + 90);

        else if (startPosition.latitude >= endPosition.latitude && startPosition.longitude >= endPosition.longitude)
            return (float) ((Math.toDegrees(Math.atan(lat / lng))) + 180);
        else if (startPosition.latitude < endPosition.latitude && startPosition.longitude >= endPosition.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lat / lng))) + 270);

        return -1;

    }

*/
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder().setDefaultFontPath("fonts/Arkhip_font.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build());

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.

        // polylines
        polylines = new ArrayList<>();


        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);// making toolbar ur actionBar


        //initialize trafficLegend
        // final MaterialCardView trafficLegend = (MaterialCardView) findViewById(R.id.trafficLegend_layout1);


        //initialize trafficLegendExpandableLayout
        // final ExpandableRelativeLayout trafficLegendExpandableLayout = (ExpandableRelativeLayout) findViewById(R.id.trafficLegend_expLayout);


       /*
        MaterialCardView becomeRider = (MaterialCardView) findViewById(R.id.becomeRider);

        becomeRider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(DriverMapActivity.this, "Become a driver", Toast.LENGTH_SHORT).show();
            }
        });

        */


        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        wholeScreen = findViewById(R.id.mapScreenLayout);


        navigationView.setCheckedItem(R.id.nav_map);
        navigationView.bringToFront();


        //initialize autocompleteCardView for search
        final MaterialCardView autocompleteCardView = (MaterialCardView) findViewById(R.id.autocompleteCardView);


        ImageView searchPlace = (ImageView) findViewById(R.id.searchPlace);
        searchPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (autocompleteCardView.getVisibility() == View.VISIBLE) {
                    autocompleteCardView.setVisibility(View.GONE);
                } else {
                    autocompleteCardView.setVisibility(View.VISIBLE);
                }

            }
        });

        final MaterialCardView trafficLegend_cardView = (MaterialCardView) findViewById(R.id.trafficLegend_cardView);
        trafficLegendButton = findViewById(R.id.trafficLegend_button);


        // floating button
        FloatingActionButton searchFloatingActionButton = (FloatingActionButton) findViewById(R.id.searchFab);
        FloatingActionButton trafficFloatingActionButton = (FloatingActionButton) findViewById(R.id.traffficFab);
        FloatingActionButton darkLightMapfloatingActionButton = (FloatingActionButton) findViewById(R.id.dark_light_MapFab);


        //both codes work but i reduced it by a line of code
        searchFloatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(DriverMapActivity.this, "Search Place", Toast.LENGTH_SHORT).show();
              /* if (autocompleteCardView.getVisibility()==View.GONE){
                   autocompleteCardView.setVisibility(View.VISIBLE);
               }else {
                   if (autocompleteCardView.getVisibility() == View.VISIBLE) {
                       autocompleteCardView.setVisibility(View.GONE);
                   }
               }

               */

                if (autocompleteCardView.getVisibility() == View.VISIBLE) {
                    autocompleteCardView.setVisibility(View.GONE);
                } else {
                    autocompleteCardView.setVisibility(View.VISIBLE);
                }


            }
        });


        trafficFloatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mMap.setTrafficEnabled(true);
                if (mMap.isTrafficEnabled()) {
                    mMap.setTrafficEnabled(false);
                    Toast.makeText(MapsActivity.this, "Traffic Disabled", Toast.LENGTH_SHORT).show();
                } else {
                    mMap.setTrafficEnabled(true);

                    Toast.makeText(MapsActivity.this, "Traffic Enabled", Toast.LENGTH_SHORT).show();
                }

                // Toast.makeText(DriverMapActivity.this, "You clicked traffic", Toast.LENGTH_SHORT).show();

                //hide or show traffic legend
                if (trafficLegend_cardView.getVisibility() == View.VISIBLE) {
                    trafficLegend_cardView.setVisibility(View.GONE);
                } else {
                    trafficLegend_cardView.setVisibility(View.VISIBLE);
                }


            }
        });

        /*darkLightMapfloatingActionButton.setOnClickListener(new View.OnClickListener() {
//            boolean  isMapStyleLight = false;
            @Override
            public void onClick(View v) {


                GoogleMap googleMap = null;
                switch (v.getId())
                {
                    case R.id.dark_light_MapFab:{
                        if(isMapStyleLight) {
                            assert googleMap != null;
                            googleMap.setMapStyle(
                                    MapStyleOptions.loadRawResourceStyle(DriverMapActivity.this, R.raw.light_map_style));
                            isMapStyleLight=false;
                            Toast.makeText(DriverMapActivity.this, "You set Light Map Style", Toast.LENGTH_SHORT).show();
                        } else{
                            assert false;
                            googleMap.setMapStyle(
                                    MapStyleOptions.loadRawResourceStyle(
                                            DriverMapActivity.this, R.raw.dark_map_style));
                            isMapStyleLight=true;
                            Toast.makeText(DriverMapActivity.this, "You set Dark Map Style", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
*/

        //used when activity has a default action bar

        /*getSupportActionBar().setTitle("bYEEP app");
        getSupportActionBar().setSubtitle("beep to your convenience");
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // this line sets default back icon
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu_icon);  // use this line to customize ur back icon


         */


        // create and toggle ur drawer menu icon with rotating animation
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        //  navigate to current location
        MaterialCardView locationImageLayout = (MaterialCardView) findViewById(R.id.locationImageLayout);
        locationImageLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()), 15.5f));
            }
        });


        //location_switch

        locationSwitch = findViewById(R.id.location_switch);


        locationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                    //add multiple markers for predefined pickup/destination locations when online

                    startLocationUpdates();
                    displayLocation();

                    Snackbar.make(mapFragment.getView(), "You are Online...", Snackbar.LENGTH_LONG).show();

                    findUserButton.setText("You're Online");

                } else {
                    stopLocationUpdates();
                    if (mUserMarker != null) {
                        mUserMarker.remove();
                    }
                    erasePolylines();


                    //remove animation for route
                   /* mMap.clear();
                    if (handler != null) {
                        handler.removeCallbacks(drawPathRunnable);
                    }*/

                    Snackbar.make(mapFragment.getView(), "You are Offline...", Snackbar.LENGTH_LONG).show();


                    findUserButton.setText("You're Offline");
                }


            }

        });

        findUserButton = (Button) findViewById(R.id.findUser);


        polyLineList = new ArrayList<>();


        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyBEVeqt-U8d1XoWPg-fMeeHhfXliAn4d74");
        }

        // Create a new Places client instance.
        PlacesClient placesClient = Places.createClient(this);


       /* typeFilter = new AutocompleteFilter.Builder()
                .setTypeFilter(AutocompleteFilter.TYPE_FILTER_ADDRESS)
                .setTypeFilter(3)
                .build();

        */
        // Initialize the AutocompleteSupportFragment.
        places = (AutocompleteSupportFragment) getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);

        // Specify the types of place data to return.
        places.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME));

        // Set up a PlaceSelectionListener to handle the response.
        places.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                if (locationSwitch.isChecked()) {

                    destination = place.getName().toString();
                    destinationLatLng = place.getLatLng();
                    destination = destination.replace("", "");
                    if (destinationMarker !=null){
                        destinationMarker.remove();
                    }

                    destinationMarker = mMap.addMarker(new MarkerOptions().position(place.getLatLng()).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(destinationLatLng, 15));
                   // getDirection();
                    getRouteToDestination();

                } else {
                    Toast.makeText(MapsActivity.this, "Please you are Offline", Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onError(@NonNull Status status) {
                Toast.makeText(MapsActivity.this, "" + status.toString(), Toast.LENGTH_SHORT).show();

            }
        });





      /*  Gobtn = (Button) findViewById(R.id.btnGo);

        editPlace = (EditText) findViewById(R.id.placeEdit);

        Gobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                destination = editPlace.getText().toString();
                destination = destination.replace(" ", "+");  // replace destination address with + to search data
                Log.d("EDMTDEV", destination);

                getDirection();


            }
        });    */


        // write driver online to database

        setUpLocation();

//        mService = Common.getGoogleAPI();

        animateNavigationDrawer();

    }

    private void getRouteToDestination() {
        currentPosition = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());

        Routing routing = new Routing.Builder()
                .travelMode(AbstractRouting.TravelMode.DRIVING)
                .withListener(this)
                .alternativeRoutes(true)
                .waypoints(currentPosition, destinationLatLng)
                .build();
        routing.execute();

    }

    private void animateNavigationDrawer() {

        drawer.setScrimColor(getResources().getColor(R.color.colorPrimary));

        drawer.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                // Scale the view based on slideOffset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float OffsetScale = 1 - diffScaledOffset;
                wholeScreen.setScaleX(OffsetScale);
                wholeScreen.setScaleY(OffsetScale);


//                Translate view to account for the scale width

                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = wholeScreen.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                wholeScreen.setTranslationX(xTranslation);


            }
        });

    }


    public void btnLegend(View view) {
        ExpandableRelativeLayout trafficLegendExpandableLayout = (ExpandableRelativeLayout) findViewById(R.id.trafficLegend_expLayout);

        trafficLegendExpandableLayout.toggle();

        trafficLegendExpandableLayout.expand();

        trafficLegendExpandableLayout.collapse();


        // trafficLegendExpandableLayout.initLayout();

    }


    public void setSupportActionBar(Toolbar toolbar) {
        //setSupportActionBar(toolbar);

    }


   /* public void getDirection() {
        *//*final double latitude = mLastLocation.getLatitude();
        final double longitude = mLastLocation.getLongitude();
        LatLng currentPosition = new LatLng(latitude, longitude);
      *//*
        currentPosition = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());


        String requestApi = null;

        try {
            requestApi = "https://maps.googleapis.com/maps/api/directions/json?" +
                    "mode=driving&" +
                    "transit_routing_preference=less_driving&" +
                    "origin=" + currentPosition + "&" +
                    "destination=" + destinationLatLng + "&" +
                    "key=" + getResources().getString(R.string.google_direction_api);

            Log.d("RICHIERICH", requestApi);  // print url for debug
            mService.getPath(requestApi)
                    .enqueue(new Callback<String>() {
                        @Override
                        public void onResponse(Call<String> call, Response<String> response) {
                            try {
                                JSONObject jsonObject = new JSONObject(response.body().toString());

                                JSONArray jsonArray = jsonObject.getJSONArray("routes");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject route = jsonArray.getJSONObject(i);
                                    JSONObject poly = route.getJSONObject("overview_polyline");
                                    String polyline = poly.getString("points");
                                    polyLineList = decodePoly(polyline);

                                }
                                //Adjust Bounds
                                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                                for (LatLng latLng : polyLineList)
                                    builder.include(latLng);
                                LatLngBounds bounds = builder.build();
                                CameraUpdate mCameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, 2);
                                mMap.animateCamera(mCameraUpdate);

                                polylineOptions = new PolylineOptions();
                                polylineOptions.color(Color.GRAY);
                                polylineOptions.width(5);
                                polylineOptions.startCap(new SquareCap());
                                polylineOptions.endCap(new SquareCap());
                                polylineOptions.jointType(JointType.ROUND);
                                polylineOptions.addAll(polyLineList);
                                greyPolyline = mMap.addPolyline(polylineOptions);


                                blackPolylineOptions = new PolylineOptions();
                                blackPolylineOptions.color(Color.BLACK);
                                blackPolylineOptions.width(5);
                                blackPolylineOptions.startCap(new SquareCap());
                                blackPolylineOptions.endCap(new SquareCap());
                                blackPolylineOptions.jointType(JointType.ROUND);
                                blackPolyline = mMap.addPolyline(blackPolylineOptions);

                               destinationMarker= mMap.addMarker(new MarkerOptions().position(polyLineList.get(polyLineList.size() - 1)).title("Destination").icon(BitmapDescriptorFactory.fromResource(R.drawable.client)));


//                                Animation
                             ValueAnimator polyLineAnimator = ValueAnimator.ofInt(0, 100);
                                polyLineAnimator.setDuration(2000);
                                polyLineAnimator.setInterpolator(new LinearInterpolator());
                                polyLineAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                                    @Override
                                    public void onAnimationUpdate(ValueAnimator valueAnimator) {
                                        List<LatLng> points = greyPolyline.getPoints();
                                        int percentValue = (int) valueAnimator.getAnimatedValue();
                                        int size = points.size();
                                        int newPoints = (int) (size * (percentValue / 100.0f));
                                        List<LatLng> p = points.subList(0, newPoints);
                                        blackPolyline.setPoints(p);


                                    }


                                });

                                //Add Animation of car for route
//                                polyLineAnimator.start();

                               mUserMarker = mMap.addMarker(new MarkerOptions().position(currentPosition).flat(true).icon(BitmapDescriptorFactory.fromResource(R.drawable.car)));

                                handler = new Handler();
                                index = -1;
                                next = 1;
                                handler.postDelayed(drawPathRunnable, 3000);


                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        }

                        @Override
                        public void onFailure(Call<String> call, Throwable t) {
                            Toast.makeText(MapsActivity.this, "" + t.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
*/
    //decodePoly class code gotten fron online from
    // https://github.com/bashantad/Tourfit-android/blob/master/src/com/example/tourfit/DirectionsJSONParser.java

   /* private List<LatLng> decodePoly(String encoded) {

        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            poly.add(p);
        }

        return poly;
    }
*/

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (checkPlayServices()) {
                        buildGoogleApiClient();
                        createLocationRequest();
                        if (locationSwitch.isChecked()) {
                            displayLocation();
                        }

                    }


                }
            }
        }
    }


    private void setUpLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            //Request runtime permission
            ActivityCompat.requestPermissions(MapsActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
            }, MY_PERMISSION_REQUEST_CODE);

        } else {
            if (checkPlayServices()) {
                buildGoogleApiClient();
                createLocationRequest();
                if (locationSwitch.isChecked()) {
                    displayLocation();
                }
            }

        }


    }


    // GravityCompat.START is for when drawer is drawn from start (left side)
    //GravityCompat.END would be for when drawer is drawn from end (right side)
    @Override
    public void onBackPressed() {
        //drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
            navigationView.setCheckedItem(R.id.nav_map);
        } else {
            super.onBackPressed();
        }
    }

    private void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(UPDATE_INTERVAL);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        //PRIORITY_HIGH_ACCURACY consumes more phone battery power
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setSmallestDisplacement(DISPLACEMENT);


    }


    private void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();

    }

    // check if Google Play Services are installed on user's device
    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this, PLAY_SERVICE_RES_REQUEST).show();
            } else {
                Toast.makeText(this, "Please your device is not Supported", Toast.LENGTH_LONG).show();
                finish();
            }
            return false;

        }

        return true;

    }


    //remove Location with removeLocationUpdates when offline without locationRequest

    private void stopLocationUpdates() {


        LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);


       /* String driverId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference driverAvailableRef = FirebaseDatabase.getInstance().getReference("driversAvailable");
        GeoFire geoFire = new GeoFire(driverAvailableRef);
        geoFire.removeLocation(driverId);  */


    }

    private void startLocationUpdates() {
// this adds the blue dot to represent ur current updated location ..u can set it to false if u dnt want it

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
//        add blue dot to location
        mMap.setMyLocationEnabled(true);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            //Request runtime permission
            ActivityCompat.requestPermissions(MapsActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
            }, MY_PERMISSION_REQUEST_CODE);
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);


    }


    // rotate marker
    //remember to change int to float
    //it was private
    //GoogleMap mMap
    private void rotateMarker(final Marker mDriverMarker, final float toRotation) {


        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final float startRotation = mDriverMarker.getRotation();
        final long duration = 1500;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed / duration);
                float rot = t * toRotation + (1 - t) * startRotation;
                mDriverMarker.setRotation(-rot > 180 ? rot / 2 : rot);


                if (t < 1.0) {
                    handler.postDelayed(this, 16);
                }


            }
        });


    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

//        set light_map_style as the default start map
        try {
            boolean isSuccess = googleMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.light_map_style));

            if (!isSuccess) {
                Log.e("ERROR", "Failed to load map");
            }

        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        }


        mMap = googleMap;


//        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mMap.setTrafficEnabled(false);


        mMap.setBuildingsEnabled(false);
        mMap.setIndoorEnabled(false);
        mMap.getUiSettings().setZoomControlsEnabled(false);


        mMap.getUiSettings().setMyLocationButtonEnabled(false); //this set as false removes the setMyLocationButtonEnabled button from map even if mMap.setMyLocationEnabled is set to true (adds the blue dot to represent current updated location)

        mMap.setInfoWindowAdapter(new CustomInfoWindow(this)); //this makes the custom info window display as designed

        mMap.getUiSettings().setCompassEnabled(false);
        mMap.getUiSettings().setZoomGesturesEnabled(true);  //allows you to zoom in and out manually without a button


        // Add some markers to the map, and add a data object to each marker.


        // Set a listener for marker click.
        mMap.setOnMarkerClickListener(this);


    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        displayLocation();
        startLocationUpdates();


    }
    // display location

    private void displayLocation() {
// if location request permission is not granted by user then return (ie. no location is shown and subsequent methods to be executed after location permission is granted dnt start at all)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        if (mLastLocation != null) {

            if (locationSwitch.isChecked()) {
                //get the double or more accurate values ( ie. more decimal points) of variables, latitude and longitude
                // of driver's location

                final double latitude = mLastLocation.getLatitude();
                final double longitude = mLastLocation.getLongitude();

                //update to firebaseDatabase


                //add Marker to current location
                //if marker is already on the map for
                // location, remove it and set marker to updated location
                if (mUserMarker != null) {
                    mUserMarker.remove();
                }
                LatLng currentLocation = new LatLng(latitude, longitude);
                if (mUserMarker != null) {
                    mUserMarker.remove();

                }

                //default marker being transparent and draggable
                mUserMarker =mMap.addMarker(new MarkerOptions().position(currentLocation).title("My Location").icon(BitmapDescriptorFactory.fromResource(R.drawable.otrafycfilled1)).anchor(0.5f, 0.5f).flat(true));

                // mDriverMarker.setRotation(getBearing(startPosition, endPosition));
                //mDriverMarker.showInfoWindow();

                //move camera to this location
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 15.5f));


            }

        } else {
            Log.d("ERROR!!", "Cannot get your location");

        }


    }


    @Override
    public void onConnectionSuspended(int i) {
        mGoogleApiClient.connect();

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    @Override
    public void onLocationChanged(Location location) {

        mLastLocation = location;
        displayLocation();


    }


    @Override
    public boolean onMarkerClick(Marker marker) {

// Retrieve the data from the marker.
        Integer clickCount = (Integer) marker.getTag();

        // Check if a click count was set, then display the click count.
        if (clickCount != null) {
            clickCount = clickCount + 1;
            marker.setTag(clickCount);

            //if number of marker clicks is more than 1 (! = 1) ..u can set the function if so
           /* if (clickCount != 1 ){

            }

            */
            Toast.makeText(this, marker.getTitle() + " has been clicked " + clickCount + " times.", Toast.LENGTH_SHORT).show();
        }

        // Return false to indicate that we have not consumed the event and that we wish
        // for the default behavior to occur (which is for the camera to move such that the
        // marker is centered and for the marker's info window to open, if it has one).
        return false;
    }


   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        //MenuInflater inflater = getMenuInflater();
        //inflater.inflate(R.menu.options_menu, menu);
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;


    }

    */

    /*@Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.optionsMenuFAQ){

            startActivity(new Intent(this, FaqActivity.class));
            return false;

        }else
            if (id == R.id.optionsMenuSettings) {

                Toast.makeText(DriverMapActivity.this, "You clicked Settings", Toast.LENGTH_SHORT).show();



            }
        else


        if (id == R.id.optionsMenuShare){

            Toast.makeText(getApplicationContext(), "You clicked Share", Toast.LENGTH_SHORT).show();



        }else


        //this is for changing light map to dark map style
        if (id == R.id.optionsMenuDarkMap){

            boolean darkMap = false;
            if(darkMap){
                darkMap = true;

            }

            Toast.makeText(DriverMapActivity.this, "You clicked Dark Map", Toast.LENGTH_SHORT).show();


        }else

        if (id == R.id.optionsMenuSearchPlace){

            Toast.makeText(DriverMapActivity.this, "You clicked Search", Toast.LENGTH_SHORT).show();


        }



       /* switch (item.getItemId()){

            case R.id.optionsMenuFAQ:
                Intent intent = new Intent (this, FaqActivity.class);
                this.startActivity(intent);

                break;


            case R.id.optionsMenuSettings:

                Toast.makeText(DriverMapActivity.this, "You clicked Settings", Toast.LENGTH_SHORT).show();
                break;


            case R.id.optionsMenuShare:
                Toast.makeText(DriverMapActivity.this, "You clicked Share", Toast.LENGTH_SHORT).show();


                break;

            case R.id.optionsMenuSearchPlace:
                Toast.makeText(DriverMapActivity.this, "You clicked Search", Toast.LENGTH_SHORT).show();

                break;

            case R.id.optionsMenuDarkMap:
                Toast.makeText(DriverMapActivity.this, "You clicked Dark Map", Toast.LENGTH_SHORT).show();


                break;



        }



       // return onOptionsItemSelected(item);


        return onOptionsItemSelected(item);



    }

     */


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {


            case R.id.nav_map:
                // getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new Profile()).commit();


                break;

            case R.id.nav_profile:
                // getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new Profile()).commit();

//                startActivity(new Intent(DriverMapActivity.this, ProfileActivity.class));


                break;

            case R.id.nav_tripHistory:
//                startActivity(new Intent(MapsActivity.this, TripHistoryActivity.class));


                break;

            case R.id.nav_earnings:
//                startActivity(new Intent(DriverMapActivity.this, EarningsActivity.class));


                break;


            case R.id.nav_emergency_contacts:
//                startActivity(new Intent(DriverMapActivity.this, EmergencyContactsActivity.class));

                break;


            case R.id.nav_settings:
//                put intent here

                break;


            case R.id.nav_inviteFriends:
                //startActivity(new Intent(DriverMapActivity.this, InviteFriendsActivity.class));


                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = "Hi there! Are you going somewhere today? \nI use OTrafyc as my guide for my daily commutes \nIts an app you should try \nPlease Download it for free on Google Play Store Here!!! " + " https://play.google.com/store/apps/details?id=";
                String shareSub = "Download OTrafyc for GPS Navigation, Live Road Traffic, Fastest Routes and Turn by Turn Directions  !!!";
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, shareSub);
                sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody + BuildConfig.APPLICATION_ID);
                startActivity(Intent.createChooser(sharingIntent, "Invite friends via"));

                break;


            case R.id.nav_rateUs:
//                 startActivity(new Intent(DriverMapActivity.this, RateUsActivity.class));

//               you can  replace getPackageName() with byeep package name as a string (ie. "com.byeep.driverapp.test1")
                try {
                    Intent rateUsIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName()));
                    startActivity(rateUsIntent);

                } catch (ActivityNotFoundException e) {

                    Intent playStore = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName()));
                    startActivity(playStore);

                }


                break;


            case R.id.nav_faq:
//                startActivity(new Intent(DriverMapActivity.this, FaqActivity.class));


                break;

            case R.id.nav_driverSupport:
//                startActivity(new Intent(DriverMapActivity.this, DriverSupportActivity.class));

                break;


            case R.id.nav_signOut:
            /*    signOut();
                Toast.makeText(MapsActivity.this, "You are signed out!", Toast.LENGTH_LONG).show();
*/

                break;


        }

        drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        navigationView.setCheckedItem(R.id.nav_map);
        return true;
    }



   /* private void signOut() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(MapsActivity.this, MainActivity.class);
        startActivity(intent);
        finish();

    }
*/


    boolean isMapStyleLight = false;

    public void changeMapStyle(View view) {

        switch (view.getId()) {
            case R.id.dark_light_MapFab: {
                if (isMapStyleLight) {
                    mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.light_map_style));
                    isMapStyleLight = false;
                    Toast.makeText(this, "You set Light Map Style", Toast.LENGTH_SHORT).show();

//                    change background color and text color of legend button when map is light
//                    make trafficLegend_cardView and trafficLegendButton global variables to get access to them in this method

                    trafficLegendButton.setBackgroundColor(getResources().getColor(R.color.smokyBlack));
                    trafficLegendButton.setTextColor(getResources().getColor(R.color.quantum_white_text));
                } else {

                    mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.dark_map_style));
                    isMapStyleLight = true;
                    Toast.makeText(MapsActivity.this, "You set Dark Map Style", Toast.LENGTH_SHORT).show();

//                    change background color and text color of legend button when map is dark
//                    make trafficLegend_cardView and trafficLegendButton global variables to get access to them in this method

                    trafficLegendButton.setBackgroundColor(getResources().getColor(R.color.quantum_white_text));
                    trafficLegendButton.setTextColor(getResources().getColor(R.color.smokyBlack));
                }
            }
        }

    }

    @Override
    public void onRoutingFailure(RouteException e) {
        if(e != null) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(this, "Something went wrong, Try again", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRoutingStart() {

    }

    @Override
    public void onRoutingSuccess(ArrayList<Route> route, int shortestRouteIndex) {

        if(polylines.size()>0) {
            for (Polyline poly : polylines) {
                poly.remove();
            }
        }

        polylines = new ArrayList<>();
        //add route(s) to the map.
        for (int i = 0; i <route.size(); i++) {

            //In case of more than 5 alternative routes
            int colorIndex = i % COLORS.length;

            PolylineOptions polyOptions = new PolylineOptions();
            polyOptions.color(getResources().getColor(COLORS[colorIndex]));
            polyOptions.width(10 + i * 3);
            polyOptions.addAll(route.get(i).getPoints());
            Polyline polyline = mMap.addPolyline(polyOptions);
            polylines.add(polyline);

            Toast.makeText(getApplicationContext(),"Route "+ (i+1) +": distance - "+ route.get(i).getDistanceValue()+": duration - "+ route.get(i).getDurationValue(),Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onRoutingCancelled() {

    }

    private void erasePolylines() {

        for (Polyline line : polylines) {
            line.remove();
        }
        polylines.clear();
    }
}

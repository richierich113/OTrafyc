package com.otrafyc.android.traffic.otrafycapp;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class SplashActivity extends AppCompatActivity {

    //call views
    TextView trafyc, slogan, welcome;
    //call animations
    Animation topAnim, bottomAnim, welcomeAnim;
    LottieAnimationView trafficLottie;


    //this is a global variable and can be converted to a local variable by using just define it as
    // int SPLASH_TIME = 7000; before the handler
    private static int SPLASH_TIME = 7000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);  //hiding status bar in activity
        setContentView(R.layout.activity_splash);


        trafyc = (TextView) findViewById(R.id.trafycView);
        slogan = (TextView) findViewById(R.id.sloganView);
        welcome = (TextView) findViewById(R.id.welcomeView);
        trafficLottie = (LottieAnimationView) findViewById(R.id.animation_view);



        //init animations
        topAnim = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);
        welcomeAnim = AnimationUtils.loadAnimation(this, R.anim.welcome_animation);


        //set animations to views
        trafyc.setAnimation(topAnim);
        slogan.setAnimation(bottomAnim);
        welcome.setAnimation(welcomeAnim);
        trafficLottie.setAnimation(bottomAnim);


        //set delay of activity before launching next activity with intent
        new  Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, MapsActivity.class);
                startActivity(intent);
                finish();
            }
        }, SPLASH_TIME);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
